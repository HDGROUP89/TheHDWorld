<?php

header("Content-type: image/png");

$img_width = 800;
$img_height = 600;

$img = imagecreatetruecolor($img_width, $img_height);

$black = imagecolorallocate($img, 0, 0, 0);
$white = imagecolorallocate($img, 255, 255, 255);

imagefill($img, 0, 0, $white);


imageellipse($img, 50, 50, 50, 50, $black);

ImageLine($img, 75, 50, 475, 50, $black);

imageellipse($img, 500, 50, 50, 50, $black);

ImageLine($img, 100, 150, 50, 75, $black);

imageellipse($img, 125, 150, 50, 50, $black);

ImageLine($img, 450, 150, 500, 75, $black);

imageellipse($img, 425, 150, 50, 50, $black);

ImageLine($img, 250, 225, 125, 175, $black);

imageellipse($img, 275, 225, 50, 50, $black);

ImageLine($img, 425, 175, 300, 225, $black);


imagepng($img);

?>