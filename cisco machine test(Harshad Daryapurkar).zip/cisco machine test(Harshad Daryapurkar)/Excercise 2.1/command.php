a)--
telnet hostname="" or=""
Example:
telnet localhost


b)--
SSH username@ip-address or hostname
harshad@virtualbox:~$ ssh harshad@68.233.250.32


c)--
df -H


d)--
ls command 
 $ ls -li filename
$ ls -li /etc/resolv.conf
stat command
$ stat fileName-Here
$ stat /etc/passwd


e)--
find $PWD in bash
ls command in linux


f)--
get - copy one file from the remote to the local machine.
mget - copy multiple files from the remote to the local machine.

