<?php
class User{
 
    private $conn;
    private $table_name = "router_details";
 
    // object properties
    public $router_id;
    public $sapid;
    public $hostname;
    public $loopback;
    public $mac_address;
 
    public function __construct($db){
        $this->conn = $db;
    }
 


function create(){
 
    $query = "INSERT INTO " . $this->table_name . "
            SET
                sapid = :sapid,
                hostname = :hostname,
                loopback = :loopback,
                mac_address = :mac_address";
 
    $stmt = $this->conn->prepare($query);
 
    $this->sapid=htmlspecialchars(strip_tags($this->sapid));
    $this->hostname=htmlspecialchars(strip_tags($this->hostname));
    $this->loopback=htmlspecialchars(strip_tags($this->loopback));
    $this->mac_address=htmlspecialchars(strip_tags($this->mac_address));
 
    $stmt->bindParam(':sapid', $this->sapid);
    $stmt->bindParam(':hostname', $this->hostname);
    $stmt->bindParam(':loopback', $this->loopback);
    $stmt->bindParam(':mac_address', $this->mac_address);
    
    if($stmt->execute()){
        return true;
    }
 
    return false;
}
 
function checkunique(){
 
    $query = "SELECT router_id, hostname, loopback
            FROM " . $this->table_name . "
            WHERE hostname = ?
            LIMIT 0,1";
 
    $stmt = $this->conn->prepare( $query );
  
    $stmt->bindParam(1, $this->hostname);

    $stmt->execute();
 
    $num = $stmt->rowCount();
 
    if($num>0){
 
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
 
        $this->router_id = $row['router_id'];
        $this->sapid = $row['sapid'];
        $this->hostname = $row['hostname'];
        $this->loopback = $row['loopback'];
        $this->mac_address = $row['mac_address'];

 
        return true;
    }
 
    return false;
}
 
public function update(){
  
    $query = "UPDATE " . $this->table_name . "
            SET
                sapid = :sapid,
                hostname = :hostname,
                loopback = :loopback
                mac_address = :mac_address
                WHERE router_id = :router_id";
 
    $stmt = $this->conn->prepare($query);
 
    $this->sapid=htmlspecialchars(strip_tags($this->sapid));
    $this->hostname=htmlspecialchars(strip_tags($this->hostname));
    $this->loopback=htmlspecialchars(strip_tags($this->loopback));
    $this->mac_address=htmlspecialchars(strip_tags($this->mac_address));
    
    $stmt->bindParam(':sapid', $this->sapid);
    $stmt->bindParam(':hostname', $this->hostname);
    $stmt->bindParam(':loopback', $this->loopback);
    $stmt->bindParam(':mac_address', $this->mac_address);
  
    $stmt->bindParam(':router_id', $this->router_id);
 
    if($stmt->execute()){
        return true;
    }
 
    return false;
}


}